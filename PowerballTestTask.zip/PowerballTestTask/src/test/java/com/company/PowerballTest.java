package com.company;

import com.sun.org.apache.xpath.internal.operations.Bool;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class PowerballTest {
    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testInArray() {
        System.out.println("inArray");
        int[] arr = new int[]{43, 21, 41, 2, 11};
        int num = 5;
        Boolean expResult = false;
        Boolean result = Powerball.inArray(arr, num);
        assertEquals(expResult, result);
    }

    @Test
    public void testCalcFactorial() {
        System.out.println("calcFactorial");
        int num = 4;
        double expResult = 24;
        double result = Powerball.calcFactorial(num);
        assertEquals(expResult, result, 1);
    }

    @Test
    public void testCalcSameCount() {
        System.out.println("calcSameCount");
        int[] a = new int[]{3, 4, 5, 2, 6};
        int[] b = new int[]{1, 4, 5, 2, 6};
        int expResult = 4;
        int result = Powerball.calcSameCount(a, b);
        assertEquals(expResult, result);
    }

    @Test
    public void testCalcProbability() {
        System.out.println("calcProbability");
        int sameCount = 1;
        Boolean samePowerball = true;
        double expResult = 1794;
        double result = Powerball.calcProbability(sameCount, samePowerball);
        assertEquals(expResult, result, 1);
        //int result = Powerball.calcSameCount(a, b
    }
}