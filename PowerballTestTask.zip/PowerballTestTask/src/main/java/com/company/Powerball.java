package com.company;

import java.util.*;

public class Powerball {
    private int tries;
    private int cost = 2;       // cost for 1 try

    private int[] winningNums = new int[5];
    private int winningPowerball;
    private int jackpot;

    private int totalPay;

    private int[] playersNums = new int[5];
    private int playerPowerball;

    private int totalWinMoney;
    private int totalWinTickets;

    private ArrayList<Integer> sameNumbers = new ArrayList<Integer>();

    Map<String, Integer> variantsWin = new HashMap<String, Integer>();

    public Powerball(int tries, int[] winningNums, int winningPowerball, int jackpot) {
        this.tries = tries;
        this.winningNums = winningNums;
        this.winningPowerball = winningPowerball;
        this.jackpot = jackpot;

        Arrays.sort(this.winningNums);
        startGame();
        finishGame();
    }

    public Powerball(int[] winningNums, int winningPowerball, int[] playersNums, int playerPowerball, int jackpot) {
        this.tries = 1;
        this.winningNums = winningNums;
        this.winningPowerball = winningPowerball;
        this.playersNums = playersNums;
        this.playerPowerball = playerPowerball;
        this.jackpot = jackpot;

        Arrays.sort(this.winningNums);
        Arrays.sort(this.playersNums);
        startGame();
        finishGame();
    }

    private void startGame() {
        this.totalPay = this.cost * this.tries;
        initVariantsWin();

        for (int t = 0; t < tries; t++ )
        {
            sameNumbers = new ArrayList<Integer>();
            initPlayerNums();  // create ticket
            initSameNumbers(); // search same numbers in tickets (without Powerball)
            if ((calcSameCount(playersNums, winningNums) >= 0 && samePowerball()) ||
                    (calcSameCount(playersNums, winningNums) >= 3 && calcSameCount(playersNums, winningNums) <= 5) && !samePowerball())
                initWinningTicket();
            Arrays.fill(playersNums, 0);
        }
    }

    private void initPlayerNums() {
        if (playersNums[0] != 0) {
            return;
        }
        Random rand = new Random();
        int randomNum;
        for (int i = 0; i<playersNums.length; i++)
        {
            while (playersNums[i] == 0)
            {
                randomNum = rand.nextInt(69) + 1;
                if (!inArray(playersNums, randomNum)) {
                    playersNums[i] = randomNum;
                }
            }
        }
        Arrays.sort(playersNums);

        playerPowerball = rand.nextInt(26) + 1;
    }

    private void initWinningTicket() {
        int winning = 0;
        String variantWin = "";
        variantWin += calcSameCount(playersNums, winningNums) +"+";
        if (samePowerball())
            variantWin+=1;
        else
            variantWin+=0;
        winning = variantsWin.get(variantWin);
        totalWinMoney+=winning;
        totalWinTickets++;

        String printString = "Variant win: " + variantWin + "|    " + "Win nums: ";


        for (int num : sameNumbers){
            printString += num + ", ";
        }
        printString +="|    Your Nums: ";
        for (int num : playersNums){
            printString += num + ", ";
        }
        printString += "|    Your Powerball: " + playerPowerball + "|     Win Nums: ";
        for (int num : winningNums){
            printString += num + ", ";
        }
        printString += "|    Win Powerball: " + winningPowerball;

        printString+="|     win: " + winning + "$";


        System.out.print(printString);
        System.out.format("%s %.0f \n", "|     Math propbability: 1:", calcProbability(calcSameCount(playersNums, winningNums), samePowerball()));

    }

    private void initSameNumbers() {
        for (int i = 0; i < playersNums.length; i++)
        {
            if (inArray(winningNums, playersNums[i]))
                sameNumbers.add(playersNums[i]);
        }
    }

    public static int calcSameCount(int[] playersNums, int[] winningNums) {
        int result = 0;
        for (int i = 0; i < playersNums.length; i++)
        {
            if (inArray(winningNums, playersNums[i]))
                result ++;
        }
        return result;
    }

    private boolean samePowerball() { return playerPowerball == winningPowerball; }

    private void initVariantsWin() {
        variantsWin.put("5+1", jackpot);
        variantsWin.put("5+0", 1000000);
        variantsWin.put("4+1", 50000);
        variantsWin.put("4+0", 100);
        variantsWin.put("3+1", 100);
        variantsWin.put("3+0", 7);
        variantsWin.put("2+1", 7);
        variantsWin.put("1+1", 4);
        variantsWin.put("0+1", 4);
    }

    public static double calcProbability(int sameCount, boolean samePowerball) {
        double top = calcFactorial(69);
        double botleft = calcFactorial(5);
        double botright = calcFactorial(69-5);
        double result = calcFactorial(69)/(calcFactorial(sameCount)*calcFactorial(69-sameCount));
        if (samePowerball)
            result*=26;
        return result;
    }

    private void finishGame() {
        System.out.println("Total win money: " + totalWinMoney + " , total win tickets: " + totalWinTickets);
    }

    public static boolean inArray(int[] array, int element) {
        for (int num : array)
        {
            if (num == element)
                return true;
        }
        return false;
    }

    public static double calcFactorial(int n) {
        double result = 1;
        for (int i = 1; i <=n; i ++){
            result = result*i;
        }
        return result;
    }
}
